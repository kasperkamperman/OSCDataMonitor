import processing.core.*; 

import processing.opengl.*; 
import processing.opengl.*; 
import oscP5.*; 
import controlP5.*; 
import java.net.InetAddress; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class OSC_Data_Monitor extends PApplet {

 /**
 * OSC DATA MONITOR. By Kasper Kamperman
 * 23-08-2011
 * based on the excellent controlP5 and oscP5 examples and libraries from Andreas Schlegel.
 * http://www.sojamo.de/libraries/controlP5/
 * http://www.sojamo.de/libraries/oscP5/
 *
 * http://www.kasperkamperman.com
 *
 * Licensed under the MIT license: 
 * http://www.opensource.org/licenses/mit-license.php 
 *
 * Compile for OPENGL (uses less CPU power) with 
 * Processing 0199 or higher and ControlP5 0.5.9
 * http://www.sojamo.de/files/archive/controlP5_0.5.9.zip
 *
**/

final String version = "23-08-2011";

 




// get IP address from this computer
InetAddress inet;
String myIP;

// store oscP5 objects
HashMap oscP5Objects;

// variabels to display incoming data
ArrayList monitorList;
HashMap monitorHash;
boolean monitorValueView = true; // switch between list and update view

int monitorListLength = 32;
String monitor;
String typetag;
char tag;
String monitorDisplay;

// variabels to filter incoming data
HashMap   oscaddressesHash;
ArrayList oscaddressesList;
int oscaddressCounter = 0;
int countFilteredaddresses; // to check if addresses are filtered

// ControlP5 interface 
ControlP5 controlP5;

Textarea mTextarea;
Textlabel ipTextlabel, infoTextlabel, text1, text2, text3, text4, text5;
ListBox list1, list2, list3, list4;
Textfield textInput;
Button button, buttonEmptyLists;
RadioButton radio;

public void setup() {
  size(800,630,OPENGL);
  frameRate(25);
    
  try {
    inet = InetAddress.getLocalHost();
    myIP = inet.getHostAddress();
  }
  catch (Exception e) {
    e.printStackTrace();
    myIP = "couldn't get IP";
  }
  
  oscP5Objects = new HashMap();
  monitorList  = new ArrayList(); 
  monitorHash  = new HashMap();   // view the last value of all addresses.
  
  oscaddressesHash         = new HashMap();
  oscaddressesList         = new ArrayList();
  countFilteredaddresses   = 0;
     
  controlP5 = new ControlP5(this);
  
  ipTextlabel   = controlP5.addTextlabel("ipTextlabel","IP address: "+myIP+" ",24,24);
  infoTextlabel = controlP5.addTextlabel("info label","OSC DATA MONITOR, version " +version+ " by kasperkamperman.com      ",24,600);
  
  list1 = controlP5.addListBox("list1",20,50,170,130);
  list1.setLabel("now listening to OSC ports:");
  list2 = controlP5.addListBox("list2",20,220,170,130);
  list2.setLabel("list with common OSC ports");
  
  text1 = controlP5.addTextlabel("text1","click on item to stop listening",24,180);
  text2 = controlP5.addTextlabel("text2","click on item to start listening",24,350);
    
  // add some common port numbers
  list2.addItem(str(3333),3333);
  list2.addItem(str(8000),8000);
  list2.addItem(str(8338),8338);
  
  // start listening to port 8000 by default
  startListeningToPort(8000);
  
  // field to add a custom port number      
  textInput = controlP5.addTextfield("textInput",20,370,170,20);
  textInput.setLabel("");
  textInput.setFocus(true);
  textInput.setAutoClear(true);
  textInput.keepFocus(true);
  
  // button to add the port number to list2
  button = controlP5.addButton("button",1,20,395,60,16);
  button.setLabel("add Port");
  
  radio = controlP5.addRadioButton("radioButton",20,430);
  radio.setNoneSelectedAllowed(false);  
  radio.setSize(20,20);
  radio.setSpacingRow(10);
  radio.addItem("view updated values",1);  
  radio.addItem("view updated addresses",0); 
    
  // text area for displaying incoming OSC data (monitor)
  mTextarea = controlP5.addTextarea(
  "textarea", "", 210,20,570,395);
  mTextarea.setLineHeight(12);
  
  //mTextarea.valueLabel().setFont(ControlP5.grixel);
  mTextarea.hideScrollbar();
  mTextarea.setColorBackground(0xff222222);  
  
  list3 = controlP5.addListBox("list3",210,430,275,130);
  list3.setLabel("received OSC addresses:");
  
  list4 = controlP5.addListBox("list4",505,430,275,130);
  list4.setLabel("monitor only OSC addresses below:"); 
 
  text3 = controlP5.addTextlabel("text3","Click on item to pass through data from this address.",214,560);
  text4 = controlP5.addTextlabel("text4","Click on item to remove filter.",509,560);
  text5 = controlP5.addTextlabel("text5","When the list above is empty all data is monitored.",509,572);
  
  buttonEmptyLists = controlP5.addButton("buttonEmptyLists",1,20,535,170,20);
  buttonEmptyLists.setLabel("Clear views");
  
  if(monitorValueView) radio.activate("view updated values");
  else                 radio.activate("view updated addresses");
  
}

public void draw() {
  // draw some background rectangles
  background(128);  
  
  fill(32);
  rect(20,20,170,15);    // textlabel
  rect(20,596,760,15);   // bottom textlabel
  fill(196);
  rect(20,50,170,125);   // list 1
  rect(20,220,170,125);  // list 2
  rect(210,430,275,125); // list 3
  rect(505,430,275,125); // list 4
  
  // empty the monitorDisplay string
  monitorDisplay = "";
  
  if(monitorValueView)
  { // fill string with data from the monitorList. 
    for(int i = 0; i < monitorList.size(); i++)
    { monitorDisplay = monitorDisplay + (String) monitorList.get(i) + "\n";
    }
  }
  else
  { Iterator iter = monitorHash.values().iterator();
      
    while (iter.hasNext()) {
      monitorDisplay = monitorDisplay + (String) iter.next() + "\n";
    } 
  }
    
  // remove items from beginning of the monitor list when size is bigger than
  // set monitorListLength
  while(monitorList.size()>monitorListLength)
  { monitorList.remove(0);   
  }  
  
  mTextarea.setText(monitorDisplay);
}

// == ControlP5 events ===========================================

public void controlEvent(ControlEvent theEvent) {
  if (theEvent.isGroup()) {
    int value = PApplet.parseInt(theEvent.group().value());
    
    if(theEvent.group().name() == "list1")
    {  stopListeningToPort(value);
    }
    
    if(theEvent.group().name() == "list2")
    {  startListeningToPort(value);          
    }
    
    if(theEvent.group().name() == "list3")
    { // check if item is already filtered     
      String s = (String) oscaddressesList.get(value);
          
      if((Integer)oscaddressesHash.get(s) == 0) 
      { list4.addItem(s, value);
        oscaddressesHash.put(s,new Integer(1));
        countFilteredaddresses++;
      }     
    }
    
    if(theEvent.group().name() == "list4")
    { String s = (String) oscaddressesList.get(value);
      
      list4.removeItem(s);
      countFilteredaddresses--;
      
      oscaddressesHash.put(s,new Integer(0));      
    }
    
    if(theEvent.group().name()=="radioButton")
    { if(theEvent.group().value() == 1) 
      { monitorValueView = true;
        mTextarea.showScrollbar();
      }
      else 
      { monitorValueView = false;
        mTextarea.hideScrollbar();
      }      
    }
   
    //println(theEvent.group());
  }
}

public void button(int theValue) {
  // trigger the textInput function below with the textInput data
  textInput.submit();
}

public void textInput(String s) {
  s = trim(s);
  
  // check if text input is a valid port number.   
  String[] m = match(s, "[^0-9]|[0-9]{6}");
  
  if(m != null)  
  { // print error in monitor
    monitorList.add((String) "- Please enter a number between 0 - 65535 "); 
  }
  else
  { if(PApplet.parseInt(s)>65535)
    { // print error in monitor
      monitorList.add((String) "- Please enter a number between 0 - 65535 ");
    }
    else
    { // add the port number to list2.
      list2.addItem(s, PApplet.parseInt(s));
    }   
  }
}

public void startListeningToPort(int port)
{ // triggered when clicking item in list2. 
  
  // check if we are not already listening by checking the Hashmap
  // add new OscListener object to the oscP5Objects HashMap
  if(!oscP5Objects.containsKey(port))
  { println(oscP5Objects.size());
    // check if HashMap size() < 10
    if(oscP5Objects.size()<10)
    { MyOSCListener o = new MyOSCListener(port);
      
      oscP5Objects.put(port,o);
      // add item to list1
      list1.addItem(str(port), port);
      monitorList.add((String) "- Listening to port: "+port); 
    }
    else
    { monitorList.add((String) "- Cannot listen to more than 10 ports"); 
    }
  } 
  else
  { monitorList.add((String) "- Already listening to port: "+port); 
  }  
}

public void stopListeningToPort(int port)
{ // triggered when clicking item in list1  
  
  if(oscP5Objects.containsKey(port))
  { // get the port from the HashMap
    MyOSCListener o = (MyOSCListener) oscP5Objects.get(port);
    
    o.stop();                   // stop listening
    oscP5Objects.remove(port);  // remove port from HashMap
    
    // remove item from list1
    String item = Integer.toString(port);
    list1.removeItem(item);
    monitorList.add((String) "- Stopped listening to port: "+port); 
  }  
}

public void buttonEmptyLists(int theValue) {
  list3.clear();
  list4.clear();
  monitorHash.clear();
  monitorList.clear();
  oscaddressesHash.clear();
  oscaddressesList.clear();
  countFilteredaddresses = 0;
  oscaddressCounter = 0;
}

// == OscListener ===============================================

class MyOSCListener {
  int port;
  OscP5 osc;
  boolean filterMessage;
  
  MyOSCListener(int thePort) {
    port = thePort;
    osc = new OscP5(this,port);
  }
  
  public void stop()
  { osc.stop();  
  }
  
  public void oscEvent(OscMessage theOscMessage) {
    
    // store address in oscaddressesHash
    addOSCaddress(theOscMessage.addrPattern());
    
    // normally all messages are filtered (pass through filter)
    // if there is an item in the oscFilteraddressedHash its 
    // compared with the incoming message if the addresses in in the Hash list
    // the message is passed through. 
    
    if(countFilteredaddresses>0)
    { filterMessage = false;
      
      if((Integer) oscaddressesHash.get(theOscMessage.addrPattern()) == 1)
      { filterMessage = true;
      }    
    }
    else filterMessage = true;
   
    // only monitor message if filter pass through is true   
    if(filterMessage)
    { // empty the monitor string
      monitor = "";
      
      // dadd address pattern to string
      monitor = "["+port+"] " + theOscMessage.addrPattern();
      
      typetag = theOscMessage.typetag();
      
      // display each data item in the monitor.   
      for(int i=0;i<typetag.length();i++)
      { tag = typetag.charAt(i);
        
        if(tag == 'i') // message has integer
        { monitor = monitor + " " + theOscMessage.get(i).intValue() + " (int)";    
        }
        else if(tag == 'f') // message has float
        { // use nfc to lmit the float to 3 decimals and convert it to a string
          monitor = monitor + " " + nfc(theOscMessage.get(i).floatValue(),3) + " (float)";
        }
        else if(tag == 's') // message has string
        { monitor = monitor + " " + theOscMessage.get(i).stringValue() + " (string)";
        }  
        else
        { // other type see documentation:
          // http://www.sojamo.de/libraries/oscP5/reference/oscP5/OscArgument.html
          // print the type tag but not the value
          monitor = monitor + " type:" + typetag;
        }
      }
      
      monitorHash.put(theOscMessage.addrPattern(),new String(monitor));
      
      //println(monitor);
      
      // add the string to the monitor list array. 
      // will be displayed in the draw() loop.
      // if statement prevents adding to much data
      // incase of a data overflow no new data is added...
      if(monitorList.size()<monitorListLength+25)
      { monitorList.add((String) monitor);          
      }
      else 
      { //println("overflow...");
      }
    }
  }
}


public void addOSCaddress(String s) {
  
   if (!oscaddressesHash.containsKey(s))
   { // Hash used to check if the adres already was used before. 
     //println("not in list yet: "+s+" "+oscaddressCounter);
     oscaddressesHash.put(s,new Integer(0));
    
     // show in list. 
     list3.addItem(s,oscaddressCounter);
     oscaddressesList.add(new String(s)); // index will be the same as the oscaddressCounter
     oscaddressCounter++;   
   }
 
}



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "OSC_Data_Monitor" });
  }
}
